﻿/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if(!SKILLBRAINS) var SKILLBRAINS={};
SKILLBRAINS.CRegistry = function(){
//							"private" variables:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var v_consoleService = Components.classes['@mozilla.org/consoleservice;1'].getService(Components.interfaces.nsIConsoleService)


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							"private" methods:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Выводит ошибку на консоль
var dConsoleError = function (message)
{
	v_consoleService.logStringMessage("Error: " + message);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
return{//					"public" variables:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
PublicProperty: "accessible as SKILLBRAINS.CRegistry.PublicProperty",



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							"public" methods:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

getRegistryValue : function (root, key, value)
{
	var retval = null;

	
	try
	{
		var wrk = Components.classes["@mozilla.org/windows-registry-key;1"]
							.createInstance(Components.interfaces.nsIWindowsRegKey);
			
		var rootkey;
		if (root == "HKLM")
		{
			rootkey = wrk.ROOT_KEY_LOCAL_MACHINE;
		}
		else if (root == "HKCU")
		{
			rootkey = wrk.ROOT_KEY_CURRENT_USER;
		}
		else
			return retval;

		wrk.open(rootkey, "", wrk.ACCESS_READ);
		if (wrk.hasChild(key)) 
		{
			var subkey = wrk.openChild(key, wrk.ACCESS_READ);
			if (subkey.hasValue(value))
			{
				switch (subkey.getValueType(value)) 
				{
					case subkey.TYPE_STRING:
					{
						retval = subkey.readStringValue(value);
						break;
					}
					case subkey.TYPE_BINARY:
					{
						retval = subkey.readBinaryValue(value);
						break;
					}
					case subkey.TYPE_INT:
					{
						retval = subkey.readIntValue(value);
						break;
					}
					case subkey.TYPE_INT64:
					{
						retval = subkey.readInt64Value(value);
						break;
					}
				}
			}
			subkey.close();
		}
		wrk.close();
	}
	catch(e){alert(e.toString())};

	
	return retval;
},

setRegistryValue : function (root, key, name, value)
{

	try
	{
		var wrk = Components.classes["@mozilla.org/windows-registry-key;1"]
							.createInstance(Components.interfaces.nsIWindowsRegKey);
			
		var rootkey;
		if (root == "HKLM")
		{
			rootkey = wrk.ROOT_KEY_LOCAL_MACHINE;
		}
		else if (root == "HKCU")
		{
			rootkey = wrk.ROOT_KEY_CURRENT_USER;
		}
		else
			return retval;
							
		wrk.create(rootkey, key, wrk.ACCESS_WRITE);
					
		//wrk.writeStringValue(name, value);//пока пишем только строки
		wrk.writeIntValue(name, value);
		
		/* //тут надо замутить запись по типам
		switch (subkey.getValueType(value)) 
		{
			case subkey.TYPE_STRING:
			{
				retval = subkey.readStringValue(value);
				break;
			}
			case subkey.TYPE_BINARY:
			{
				retval = subkey.readBinaryValue(value);
				break;
			}
			case subkey.TYPE_INT:
			{
				retval = subkey.readIntValue(value);
				break;
			}
			case subkey.TYPE_INT64:
			{
				retval = subkey.readInt64Value(value);
				break;
			}
		}
		*/

		wrk.close();
	}
	catch(e){alert(e.toString())};
	
}

		
		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							close SKILLBRAINS SKILLBRAINS.LightshotFF.Plugin object
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
};}(); // the parens here cause the anonymous function to execute and return
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							Global Namespace code
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


