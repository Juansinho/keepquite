﻿var SKILLBRAINS;
if(typeof SKILLBRAINS === 'undefined') SKILLBRAINS = {};
if(typeof SKILLBRAINS.LightshotFF === 'undefined') SKILLBRAINS.LightshotFF = {};

SKILLBRAINS.LightshotFF.Plugin = function(){

	var uuid = "{394DCBA4-1F92-4f8e-8EC9-8D2CB90CB69B}";

	var preferenceBranch = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService).getBranch("screenshot_plugin.");

	var buildLocalizationString = function(){
		var mgsIds = ['screenshot_plugin.tooltip', 'screenshot_plugin.print', 'screenshot_plugin.copy', 'screenshot_plugin.save', 
						'screenshot_plugin.cancel', 'screenshot_plugin.clear', 'screenshot_plugin.fullscreen', 'screenshot_plugin.editonline', 
						'screenshot_plugin.upload', 'screenshot_plugin.share_facebook', 'screenshot_plugin.uploading_window_capt', 
						'screenshot_plugin.share_tineyesearch', 'screenshot_plugin.open', 'screenshot_plugin.close',
						'screenshot_plugin.error_capt', 'screenshot_plugin.upload_failed_retry', 'screenshot_plugin.incorrect_size', 
						'screenshot_plugin.share_googlesearch', 'screenshot_plugin.share_twitter', 'screenshot_plugin.share_sendmail'];
		var localeString = '';
		var stringsBundle = document.getElementById("stringBundleLightshot");
		if (stringsBundle){
			for(var i=0; i<mgsIds.length; i++){
				var str = stringsBundle.getString(mgsIds[i]);
				if (str && str != ''){
					localeString += '[[' + mgsIds[i] + ']]=[[' + str + ']]';
				}
			}
		}
		return localeString;
	};

	var MakeScreenshot = function(){
		try{
			document.getElementById("LightshotNPobj").InitDll();
			var locStr = buildLocalizationString();
			document.getElementById("LightshotNPobj").SetLocalizationString(locStr);
			document.getElementById("LightshotNPobj").MakeScreenshot();
			document.getElementById("LightshotNPobj").DeinitDll();
		}catch(e){
			alert('Error: Lightshot NPAPI plugin not found. Try to reload browser. If you keep seeing this error after reloading, please contact support@skillbrains.com.');
		}
	};

	var InsertButtonInToolbar = function (str_button){
		try{
			var box=document.getElementById('nav-bar');
			if (box){	
				var newset;
				if (box.getAttribute('currentset') && box.getAttribute('currentset').indexOf(str_button) == -1){
					box.insertItem (str_button, null, null, false);
					newset=box.getAttribute('currentset') + ',' + str_button;
					box.setAttribute('currentset', newset);
					document.persist('nav-bar', 'currentset');
					BrowserToolboxCustomizeDone(true);
				}else{
					if (box.getAttribute('currentset').indexOf(str_button) == -1){
						box.insertItem (str_button, null, null, false);
						newset=box.getAttribute('defaultset') + ',' + str_button;
						box.setAttribute('currentset', newset);
						document.persist('nav-bar', 'currentset');
						BrowserToolboxCustomizeDone(true);							
					}
				}
			}	
		}catch(e){
			//alert(e);        
		}
	};

	return{
		FirstTimeRedirect : function(){
			try{
				gBrowser.selectedTab = gBrowser.addTab(preferenceBranch.getCharPref('first_page'));
			}catch(e){alert(e.toString())};
		},

		AfterUpdateRedirect : function(){
			try{
				gBrowser.selectedTab = gBrowser.addTab(preferenceBranch.getCharPref('after_update_page'));
			}catch(e){alert(e.toString())};
		},

		initPreferences : function(){
			// show/hide statuspanel icon
			document.getElementById("screenshot_pluginStatusPanel").hidden = !preferenceBranch.getBoolPref("add_statuspanel");
			// show/hide menu item and separator
			document.getElementById("screenshot_pluginMenuSeparator").hidden = !preferenceBranch.getBoolPref("add_menuitem");
			document.getElementById("screenshot_pluginMenuItem").hidden = !preferenceBranch.getBoolPref("add_menuitem");
		},

		init : function (){
			try {
				SKILLBRAINS.Utils.getVersion(uuid, function(version){		
					if (preferenceBranch.getBoolPref("first_run_1")==false)	{
						InsertButtonInToolbar('screenshot_pluginToolbarButton');
						setTimeout(SKILLBRAINS.LightshotFF.Plugin.FirstTimeRedirect, 500);
						preferenceBranch.setBoolPref("first_run_1", true);
						preferenceBranch.setCharPref('last_version', version);
					}else{
						var last_version = preferenceBranch.getCharPref('last_version');
						var current_version = version;
						if (current_version != last_version){
							InsertButtonInToolbar('screenshot_pluginToolbarButton');
							setTimeout(SKILLBRAINS.LightshotFF.Plugin.AfterUpdateRedirect, 500);
							preferenceBranch.setCharPref('last_version', version);
						}
					}
				});
			}catch(e){alert(e.toString())};
			SKILLBRAINS.LightshotFF.Plugin.initPreferences();
		},

		ToolbarButtonFunction: function(){
			MakeScreenshot();
		},

		StatusbarButtonFunction: function(event){
			if (event.button==0){//left button
				MakeScreenshot();
			}else if (event.button==2){//right button
				openDialog("chrome://screenshot_plugin/content/preferences.xul", "_blank", "chrome,centerscreen,modal");
			}
		}
	};
}();

window.addEventListener("load", SKILLBRAINS.LightshotFF.Plugin.init, true);