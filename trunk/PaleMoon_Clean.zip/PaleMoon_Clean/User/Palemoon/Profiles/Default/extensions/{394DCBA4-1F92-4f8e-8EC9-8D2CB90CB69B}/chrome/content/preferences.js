﻿
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if(!SKILLBRAINS) var SKILLBRAINS={};
if(!SKILLBRAINS.LightshotFF) SKILLBRAINS.LightshotFF={};
SKILLBRAINS.LightshotFF.Preferences = function(){
//							"private" variables:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var v_consoleService = Components.classes['@mozilla.org/consoleservice;1'].getService(Components.interfaces.nsIConsoleService)
var preferenceBranch = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService).getBranch("screenshot_plugin.")

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							"private" methods:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Выводит ошибку на консоль
var dConsoleError = function (message)
{
	v_consoleService.logStringMessage("Error: " + message);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
return{//					"public" variables:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
PublicProperty: "accessible as SKILLBRAINS.LightshotFF.Preferences.PublicProperty",



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							"public" methods:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



ReinitWindows : function()
{
	try 
	{
		var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"].getService(Components.interfaces.nsIWindowMediator);  
		var enumerator = wm.getEnumerator('navigator:browser');  
		while(enumerator.hasMoreElements()) 
		{  
			var win = enumerator.getNext();  
			var num = win.gBrowser.browsers.length;
			for (var i = 0; i < num; i++) 
			{
				//win.document.getElementById("phone_highlighter-menuitem-2").setAttribute("checked", true);
				//recalcHighlightEx(win.gBrowser.getBrowserAtIndex(i).contentWindow, win.gBrowser.getBrowserAtIndex(i).contentWindow.document);
				win.SKILLBRAINS.LightshotFF.Plugin.initPreferences();
			}
		}  
	} 
    catch(e){alert(e.toString())};
},
 

LoadSettings : function (value)
{
	/*
	var hotkey = new Object();
	hotkey.modifiers = preferenceBranch.getCharPref('hotkey_modifiers');
	hotkey.letter = preferenceBranch.getCharPref('hotkey_letter');
	hotkey.key = preferenceBranch.getCharPref('hotkey_key');

	if (false==SKILLBRAINS.Components.Hotkey.setHotKey(hotkey))
	{
		//alert('aaaaaaa');
	}
	*/

	//load format setting
	format = SKILLBRAINS.CRegistry.getRegistryValue("HKCU", "Software\\Screenshoter", "Format");
	if (format==null)
		format = 1;
	document.getElementById("imageFormat").selectedIndex = format-1;
	
	//load show/hide preferences
	document.getElementById("checkbox_add_menuitem").checked = preferenceBranch.getBoolPref("add_menuitem");
	document.getElementById("checkbox_add_statuspanel").checked = preferenceBranch.getBoolPref("add_statuspanel");
},
	
ApplySettings : function()
{
	/*
	var hotkey = SKILLBRAINS.Components.Hotkey.getHotKey();
	preferenceBranch.setCharPref('hotkey_modifiers', hotkey.modifiers);
	preferenceBranch.setCharPref('hotkey_letter', hotkey.letter);
	preferenceBranch.setCharPref('hotkey_key', hotkey.key);
	*/
	//preferenceBranch.setCharPref('last_version', SKILLBRAINS.Utils.getVersion(uuid));
	
	format = document.getElementById("imageFormat").selectedIndex+1;
	SKILLBRAINS.CRegistry.setRegistryValue("HKCU", "Software\\Screenshoter", "Format", format);

	//alert("You must restart Firefox for changes to take effect.");
	
	
	//save show/hide preferences
	preferenceBranch.setBoolPref("add_menuitem", document.getElementById("checkbox_add_menuitem").checked);
	preferenceBranch.setBoolPref("add_statuspanel", document.getElementById("checkbox_add_statuspanel").checked);
	
	//make FF windows load new settings
	SKILLBRAINS.LightshotFF.Preferences.ReinitWindows();
	
	// Closing window
	window.close();
}

		
		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							close SKILLBRAINS SKILLBRAINS.LightshotFF.Plugin object
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
};}(); // the parens here cause the anonymous function to execute and return
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							Global Namespace code
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



