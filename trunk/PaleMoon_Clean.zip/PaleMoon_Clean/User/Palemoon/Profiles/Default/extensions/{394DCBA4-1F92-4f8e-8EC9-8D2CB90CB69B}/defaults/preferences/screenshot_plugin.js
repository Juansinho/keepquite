﻿



//pref('screenshot_plugin.var1', 'value1');
pref('screenshot_plugin.first_run_1', false);
pref('screenshot_plugin.first_page', 'http://lightshot.skillbrains.com/component/content/article/2-thank-you.html');
pref('screenshot_plugin.after_update_page', 'http://lightshot.skillbrains.com/component/content/article/7-update.html');

pref('screenshot_plugin.last_version', '0');


pref('screenshot_plugin.hotkey_modifiers', 'control');
pref('screenshot_plugin.hotkey_letter', '`');
pref('screenshot_plugin.hotkey_key', '192');

pref('screenshot_plugin.add_menuitem', true);
pref('screenshot_plugin.add_statuspanel', true);

pref('dom.ipc.plugins.enabled.nplightshot.dll', false);