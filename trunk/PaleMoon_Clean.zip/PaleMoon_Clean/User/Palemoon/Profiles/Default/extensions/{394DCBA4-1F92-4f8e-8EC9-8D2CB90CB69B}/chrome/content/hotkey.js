/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if(!SKILLBRAINS) var SKILLBRAINS={};
if(!SKILLBRAINS.Components) SKILLBRAINS.Components={};
SKILLBRAINS.Components.Hotkey = function(){
//							"private" variables:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var v_consoleService = Components.classes['@mozilla.org/consoleservice;1'].getService(Components.interfaces.nsIConsoleService)
var isAltPressed = false
var isCtrlPressed = false
var isShiftPressed = false
var letter = ''
var key = ''

var bModifierAlt = false
var bModifierCtrl = false
var bModifierShift = false

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							"private" methods:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//������� ������ �� �������
var dConsoleError = function (message)
{
	v_consoleService.logStringMessage("Error: " + message);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
return{//					"public" variables:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
PublicProperty: "accessible as SKILLBRAINS.LightshotFF.Preferences.PublicProperty",



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							"public" methods:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
OnKeyDown : function(event)
{
	if ((!isShiftPressed) && (!isCtrlPressed) && (!isAltPressed))
	{
		letter = '';
		key = '';
	}

	if (event.keyCode == 16)
	{
		isShiftPressed = true;
	} 
	else if (event.keyCode == 17)
	{
		isCtrlPressed = true;
	} 
	else if (event.keyCode == 18)
	{
		isAltPressed = true;
	}
	else if ((event.keyCode >= 48) && (event.keyCode <= 90))
	{
		var alphabet = "0123456789 ;     ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		letter = alphabet[event.keyCode - 48];
		key = event.keyCode;
	}
	else if ((event.keyCode >= 188) && (event.keyCode <= 192))
	{
		var alphabet = ", ./`";
		letter = alphabet[event.keyCode - 188];
		key = event.keyCode;
	}
	else if ((event.keyCode >= 219) && (event.keyCode <= 222))
	{
		var alphabet = "[ \]'";
		letter = alphabet[event.keyCode - 219];
		key = event.keyCode;
	}

	
	
	bModifierCtrl = false;
	bModifierShift = false;
	bModifierAlt = false;
	
	var text = "";
	if (isCtrlPressed)
	{
		bModifierCtrl = true;
		text += "Ctrl + ";
	}
	if (isShiftPressed)
	{
		bModifierShift = true;
		text += "Shift + ";
	}
	if (isAltPressed)
	{
		bModifierAlt = true;
		text += "Alt + ";
	}
	text += letter;
	
	
	document.getElementById("textbox_component_hotkey").setAttribute("value", text);
},





OnKeyUp : function(event)
{

	if (event.keyCode == 16)
	{
		isShiftPressed = false;
	} 
	else if (event.keyCode == 17)
	{
		isCtrlPressed = false;
	} 
	else if (event.keyCode == 18)
	{
		isAltPressed = false;
	}

	if ((!isShiftPressed) && (!isCtrlPressed) && (!isAltPressed) && (letter==''))
	{
		document.getElementById("textbox_component_hotkey").setAttribute("value", "No");
		bModifierAlt = false;
		bModifierShift = false;
		bModifierCtrl = false;
	}
}, 


getHotKey : function()
{
	var hotkey = new Object();

	hotkey.modifiers = "";
	if (bModifierCtrl)
		hotkey.modifiers += "control ";
	if (bModifierShift)
		hotkey.modifiers += "shift ";
	if (bModifierAlt)
		hotkey.modifiers += "alt ";
		
	hotkey.letter = letter;
	hotkey.key = key;

	//alert("modifiers='" + hotkey.modifiers + "' letter='" + hotkey.letter + "' key='" + hotkey.key + "'");
	
	return hotkey;
}, 


setHotKey : function(hotkey)
{

	if ((typeof hotkey.modifiers != "undefined") && (typeof hotkey.letter != "undefined") && (typeof hotkey.key != "undefined"))
	{
		var text = "";
		if ((hotkey.modifiers=="") && (hotkey.letter==""))
		{
			text = "No";
		}
		else
		{
			if (hotkey.modifiers.indexOf('control')!=-1)
			{
				bModifierCtrl = true;
				text += "Ctrl + ";
			}
			if (hotkey.modifiers.indexOf('shift')!=-1)
			{
				bModifierShift = true;
				text += "Shift + ";
			}
			if (hotkey.modifiers.indexOf('alt')!=-1)
			{
				bModifierAlt = true;
				text += "Alt + ";
			}
			letter = hotkey.letter[0];
			key = hotkey.key;
			text += letter;
		}
		
		document.getElementById("textbox_component_hotkey").setAttribute("value", text);
		return true;
	}
	else
		return false;
	

}

		
		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							close SKILLBRAINS SKILLBRAINS.LightshotFF.Plugin object
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
};}(); // the parens here cause the anonymous function to execute and return
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//							Global Namespace code
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
