user_pref("browser.cache.disk.parent_directory", "D:\\Downloads\\PaleMoon_Clean\\User\\Palemoon\\Profiles\\Default");
user_pref("browser.download.lastDir", "D:\\Downloads\\PaleMoon_Clean\\Downloads");
user_pref("browser.safebrowsing.enabled", false);
user_pref("browser.safebrowsing.malware.enabled", false);
user_pref("browser.shell.checkDefaultBrowser", false);
